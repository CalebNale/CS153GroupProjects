// Generated from Pcl4.g4 by ANTLR 4.8

    package antlr4;

    import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;

    /**
     * This class provides an empty implementation of {@link Pcl4Visitor},
     * which can be extended to create a visitor which only needs to handle a subset
     * of the available methods.
     *
     * @param <T> The return type of the visit operation. Use {@link Void} for
     * operations with no return type.
     */
    public class Pcl4BaseVisitor<T> extends AbstractParseTreeVisitor<T> implements Pcl4Visitor<T> {
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitProgram(Pcl4Parser.ProgramContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitProgramHeader(Pcl4Parser.ProgramHeaderContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitProgramParameters(Pcl4Parser.ProgramParametersContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitBlock(Pcl4Parser.BlockContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitDeclarations(Pcl4Parser.DeclarationsContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitStatement(Pcl4Parser.StatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitCompoundStatement(Pcl4Parser.CompoundStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitEmptyStatement(Pcl4Parser.EmptyStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitStatementList(Pcl4Parser.StatementListContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitAssignmentStatement(Pcl4Parser.AssignmentStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitRepeatStatement(Pcl4Parser.RepeatStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitLhs(Pcl4Parser.LhsContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitRhs(Pcl4Parser.RhsContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteStatement(Pcl4Parser.WriteStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWritelnStatement(Pcl4Parser.WritelnStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWhileStatement(Pcl4Parser.WhileStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitForStatement(Pcl4Parser.ForStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitIfStatement(Pcl4Parser.IfStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitCaseStatement(Pcl4Parser.CaseStatementContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitExpression(Pcl4Parser.ExpressionContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitSimpleExpression(Pcl4Parser.SimpleExpressionContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitTerm(Pcl4Parser.TermContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitVariableExpression(Pcl4Parser.VariableExpressionContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitNumberExpression(Pcl4Parser.NumberExpressionContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitCharacterFactor(Pcl4Parser.CharacterFactorContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitStringFactor(Pcl4Parser.StringFactorContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitNotFactor(Pcl4Parser.NotFactorContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitParenthesizedExpression(Pcl4Parser.ParenthesizedExpressionContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitVariable(Pcl4Parser.VariableContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitNumber(Pcl4Parser.NumberContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitUnsignedNumber(Pcl4Parser.UnsignedNumberContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitIntegerConstant(Pcl4Parser.IntegerConstantContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitRealConstant(Pcl4Parser.RealConstantContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitCharacterConstant(Pcl4Parser.CharacterConstantContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitStringConstant(Pcl4Parser.StringConstantContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitSign(Pcl4Parser.SignContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitRelOp(Pcl4Parser.RelOpContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitAddOp(Pcl4Parser.AddOpContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitMulOp(Pcl4Parser.MulOpContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteArgumentsOn(Pcl4Parser.WriteArgumentsOnContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteArgumentListOn(Pcl4Parser.WriteArgumentListOnContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteArgumentsLn(Pcl4Parser.WriteArgumentsLnContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteArgumentListLn(Pcl4Parser.WriteArgumentListLnContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteArgumentList(Pcl4Parser.WriteArgumentListContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitWriteArgument(Pcl4Parser.WriteArgumentContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitFieldWidth(Pcl4Parser.FieldWidthContext ctx) { return visitChildren(ctx); }
    	/**
    	 * {@inheritDoc}
    	 *
    	 * <p>The default implementation returns the result of calling
    	 * {@link #visitChildren} on {@code ctx}.</p>
    	 */
    	@Override public T visitDecimalPlaces(Pcl4Parser.DecimalPlacesContext ctx) { return visitChildren(ctx); }
    }